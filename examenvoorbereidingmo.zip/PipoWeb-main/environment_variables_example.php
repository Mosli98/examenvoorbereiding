<?php

$db_user = ''; #Database username
$db_pass = ''; #Database password

$project_path = ''; #Where your project lies

?>