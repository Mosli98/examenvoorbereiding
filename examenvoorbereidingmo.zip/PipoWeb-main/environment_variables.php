<?php

$db_user = 'root';
$db_pass = '';

$project_path = '/examenvoorbereiding';

?>