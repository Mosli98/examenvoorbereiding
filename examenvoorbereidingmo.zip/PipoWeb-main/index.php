<?php

require_once $_SERVER['DOCUMENT_ROOT'] . '/partials/header.php';

?>



<?= require_once $_SERVER['DOCUMENT_ROOT'] . '/partials/footer.php'; ?>
