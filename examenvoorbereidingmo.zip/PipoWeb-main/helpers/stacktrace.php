// Gebruiken voor inzien.
// print_r($_SESSION);
// exit;