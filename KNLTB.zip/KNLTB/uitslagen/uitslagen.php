<?php
    include_once("../database.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>KNLTB</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
  <link rel="stylesheet" href="./uitslagen.css" ></style>
</head>
<body>
    <?php
        include_once("../navbar.php");

        function getToernooien() {
            $conn = getConnection();

            $sql = "SELECT * FROM toernooien ORDER BY toernooinaam DESC";

            $arr = array();

            foreach ($conn->query($sql) as $row) {
                $arr[] = $row;
            }
            $conn = null;

            return $arr;
        }
        function getToernooiUitslagen($toernooienid) {
            $conn = getConnection();

            $toernooiEscaped = addslashes($toernooienid);
            $sql = "SELECT * FROM uitslagen WHERE toernooienid='$toernooiEscaped' ORDER BY uitslagenid DESC";

            $arr = array();

            foreach ($conn->query($sql) as $row) {
                $arr[] = $row;
            }
            $conn = null;

            return $arr;
        }
        function getWedstrijden($toernooienid) {
            $conn = getConnection();

            $toernooiEscaped = addslashes($toernooienid);
            $sql = "SELECT wedstrijdid, Ronde, s1.voornaam as Speler1, s2.voornaam as Speler2, w.score1, w.score2
FROM `wedstrijd` w
JOIN spelers s1 ON s1.spelersid = w.speler1id
JOIN spelers s2 ON s2.spelersid = w.speler2id
 WHERE toernooienid='$toernooiEscaped'";

            $arr = array();

            foreach ($conn->query($sql) as $row) {
                $arr[] = $row;
            }
            $conn = null;

            return $arr;
        }
    ?>
    <div class="container mt-5">
        <div class="row">
            <div class="col-sm-12">
                <a href="adduitslag.php" class="btn btn-success">Toevoegen</a>
                <table class="table table-striped table-bordered mt-2">
					<thead>
					<tr>
						<td>Uitslagen nummer</td>
						<td>Speler</td>
						<td>Toernooi</td>
                        <td>Wedstrijds nummer</td>
                        <td>Uitslag</td>
					</tr>
					</thead>
					<tbody>
					<?php
                        $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
                        $sql = 'SELECT * FROM uitslagen ORDER BY uitslagenid DESC';
                        
                        foreach ($conn->query($sql) as $row) {
                            echo '<tr>';
                            echo '<td>'. $row['uitslagenid'] . '</td>';
                            echo '<td>'. $row['voornaam'] . '</td>';
                            echo '<td>'. $row['toernooinaam'] . '</td>';
                            echo '<td>'. $row['wedstrijdid'] . '</td>';
                            echo '<td>'. $row['uitslag'] . '</td>';
                            echo '<td width=250>';
                            echo '<a class="btn btn-success" href="edituitslag.php?uitslagenid='.$row['uitslagenid'].'">Wijzigen</a>';
                            echo ' ';
                            echo '<a class="btn btn-danger" href="deleteuitslag.php?uitslagenid='.$row['uitslagenid'].'">Verwijderen</a>';
                            echo '</td>';
                            echo '</tr>';
                        }
                        $conn = null;
					?>
					</tbody>
				</table>
                <div class="wrapper" id="wrapper">
                    <?php 
                        $toernooien = getToernooien();
                        foreach($toernooien as $toernooi) {
                            $toernooienid = $toernooi['toernooienid'];
                            ?>
                            <div id="round1" class="round">
                                <h4><?php echo $toernooi['toernooinaam'] ?></h4>
                                <?php
                                    $wedstrijden = getWedstrijden($toernooienid);
                                    foreach ($wedstrijden as $row) {
                                        ?>
                                        <div>
                                            <div>ronde 1 : <?=$row['Ronde']?> </div>
                                            <div>score: <?=$row['score1']?> - <?=$row['score2']?> </div>
                                            <div>speler 1 : <?=$row['Speler1']?> </div>
                                            <div>speler 2 : <?=$row['Speler2']?> </div>



                                        </div>

                                        <?php
                                    }
                                ?>
                            </div>
                            <?php
                        }
                    ?>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
